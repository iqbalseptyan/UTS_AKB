package id.web.iqbalseptyan.utsakb.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import id.web.iqbalseptyan.utsakb.R;

public class TemanFragment extends Fragment {
    ListView listView;
    EditText editText;
    Button btnAdd, btnUpdt;

    ArrayList<String> foods = new ArrayList<String>();
    ArrayAdapter arrayAdapter;

    Integer indexVal;
    String item;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.f_teman, container, false);
        listView = (ListView) view.findViewById(R.id.list_View);
        btnAdd = (Button) view.findViewById(R.id.btn_add);
        btnUpdt = (Button) view.findViewById(R.id.btn_updt);
        editText = (EditText) view.findViewById(R.id.editText);

        //setup listview
        foods.add("HAM");
        foods.add("Bread");
        arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, foods);
        listView.setAdapter(arrayAdapter);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        return view;
    }

}
