package id.web.iqbalseptyan.utsakb.Fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import id.web.iqbalseptyan.utsakb.Adapter.DataTemanAdapter;
import id.web.iqbalseptyan.utsakb.R;
import id.web.iqbalseptyan.utsakb.model.Kontak;

public class TemanFragment extends Fragment {
    private EditText eNim, eNama, eKelas, eTelp, eMail, eSosmed;
    String sNim, sNama, sKelas, sTelp, sMail, sSosmed, item;
    private DataTemanAdapter temanAdapter;

    ListView listView;
    EditText editText;
    Button btnShow, btnTmbh, btnUbh;

    ArrayList<Kontak> datas = new ArrayList<Kontak>();
    ArrayAdapter arrayAdapter;

    Integer indexVal;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.f_teman, container, false);
        listView = (ListView) view.findViewById(R.id.list_View);
        btnShow = (Button) view.findViewById(R.id.btn_Show);

        //setup listview
        //arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, datas);
        //listView.setAdapter(arrayAdapter);


        //dialog
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog mDialog = new Dialog(getActivity());
                mDialog.setContentView(R.layout.layout_dialog);
                mDialog.show();



                //id
                eNim = mDialog.findViewById(R.id.editTextNIM);
                eNama = mDialog.findViewById(R.id.editTextNL);
                eKelas = mDialog.findViewById(R.id.editTextKLS);
                eTelp = mDialog.findViewById(R.id.editTextTLP);
                eMail = mDialog.findViewById(R.id.editTextEML);
                eSosmed = mDialog.findViewById(R.id.editTextSM);

                btnTmbh = mDialog.findViewById(R.id.btn_Tmbh);
                btnUbh = mDialog.findViewById(R.id.btn_Ubh);

                //create
                btnTmbh.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        ArrayList<Kontak> kontakList = new ArrayList<>();
                        sNim = eNim.getText().toString();
                        sNama = eNama.getText().toString();
                        sKelas = eKelas.getText().toString();
                        sTelp = eTelp.getText().toString();
                        sMail = eMail.getText().toString();
                        sSosmed = eSosmed.getText().toString();
                        temanAdapter = new DataTemanAdapter(getActivity(), kontakList);

                        kontakList.add(new Kontak(sNim,sNama,sKelas,sTelp,sMail,sSosmed));
                        listView.setAdapter(temanAdapter);




                        temanAdapter.notifyDataSetChanged();
                    }
                });
                /*
                //update
                btnUbh.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sNim = eNim.getText().toString();
                        datas.set(indexVal, sNim);
                        sNama = eNama.getText().toString();
                        datas.set(indexVal, sNama);
                        sKelas = eKelas.getText().toString();
                        datas.set(indexVal, sKelas);
                        sTelp = eTelp.getText().toString();
                        datas.set(indexVal, sTelp);
                        sMail = eMail.getText().toString();
                        datas.set(indexVal, sMail);
                        sSosmed = eSosmed.getText().toString();
                        datas.set(indexVal, sSosmed);
                        arrayAdapter.notifyDataSetChanged();
                    }
                });
                */

                //select item
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        item = parent.getItemAtPosition(position).toString() + " Telah Dipilih!";
                        indexVal = position;
                        Toast.makeText(getActivity(), item, Toast.LENGTH_SHORT).show();
                    }
                });

                //delete item
                listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        item = parent.getItemAtPosition(position).toString() + " Telah Dihapus!";
                        Toast.makeText(getActivity(), item, Toast.LENGTH_SHORT).show();

                        datas.remove(position);
                        arrayAdapter.notifyDataSetChanged();
                        return false;
                    }
                });
            }

        });

        return view;

    }

    private void CustomDialog(){
        AlertDialog.Builder dialog;
        LayoutInflater inflater;
        dialog = new AlertDialog.Builder(getActivity());
        inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.layout_dialog, null);
        dialog.setView(dialogView);

    }

}
