package id.web.iqbalseptyan.utsakb.Fragment;

import android.support.v4.app.Fragment;

public class KontakFragment extends Fragment {
}
