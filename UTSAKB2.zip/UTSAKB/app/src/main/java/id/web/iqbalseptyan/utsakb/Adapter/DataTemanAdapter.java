package id.web.iqbalseptyan.utsakb.Adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

import id.web.iqbalseptyan.utsakb.R;
import id.web.iqbalseptyan.utsakb.model.Kontak;

public class DataTemanAdapter extends ArrayAdapter<Kontak> {
    private Context mContext;
    private List<Kontak> kontakList = new ArrayList<>();

    public DataTemanAdapter(@NonNull Context context,  ArrayList<Kontak> list){
        super(context, 0, list);
        mContext = context;
        kontakList = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);

        Kontak currentKontak = kontakList.get(position);

        TextView nim = (TextView) listItem.findViewById(R.id.txtNIM);
        nim.setText(currentKontak.getNim());
        TextView nama = (TextView) listItem.findViewById(R.id.txtNL);
        TextView kelas = (TextView) listItem.findViewById(R.id.txtKLS);
        TextView telp = (TextView) listItem.findViewById(R.id.txtTLP);
        TextView email = (TextView) listItem.findViewById(R.id.txtEML);
        TextView sosmed = (TextView) listItem.findViewById(R.id.txtSM);


        nama.setText(currentKontak.getNama());
        kelas.setText(currentKontak.getKelas());
        telp.setText(currentKontak.getTelepon());
        email.setText(currentKontak.getEmail());
        sosmed.setText(currentKontak.getSosmed());

        return listItem;
    }

}